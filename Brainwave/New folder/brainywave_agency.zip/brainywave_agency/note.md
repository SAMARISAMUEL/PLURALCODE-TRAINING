<i class='bx bxl-facebook-square'></i>
<i class='bx bxl-twitter' ></i>
<i class='bx bxl-instagram' style='color:#ffffff' ></i>
<i class='bx bxl-linkedin-square' style='color:#ffffff' ></i>
<i class='bx bxs-star' style='color:#ffffff' ></i>
<i class='bx bx-menu' style='color:#ffffff' ></i>
